import React, { useState } from "react";
import axios from "axios";

const Chatbot = () => {
  const [messages, setMessages] = useState<{ type: string; text: string }[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);

  const sendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = { type: "user", text: input };
    setMessages((prev) => [...prev, userMessage]);
    setLoading(true);

    try {
      const response = await axios.post("http://localhost:3000/legal-query", {
        query: input,
        userId: "123", // Replace with dynamic user handling if needed
      });

      setMessages((prev) => [
        ...prev,
        { type: "bot", text: response.data.response },
      ]);
    } catch (error) {
      setMessages((prev) => [...prev, { type: "bot", text: "Error processing request" }]);
    } finally {
      setLoading(false);
      setInput("");
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setMessages((prev) => [...prev, { type: "user", text: `Uploaded: ${file.name}` }]);

    const formData = new FormData();
    formData.append("file", file);

    try {
      const response = await axios.post("http://localhost:3000/upload-pdf", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      setMessages((prev) => [
        ...prev,
        { type: "bot", text: response.data.response },
      ]);
    } catch (error) {
      setMessages((prev) => [...prev, { type: "bot", text: "Error processing PDF" }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-4">
      <div className="w-full max-w-lg bg-white rounded-lg shadow-md p-4">
        <h2 className="text-xl font-bold mb-2 text-center">Legal Chatbot</h2>

        <div className="h-80 overflow-y-auto border p-3 rounded bg-gray-50">
          {messages.map((msg, index) => (
            <div
              key={index}
              className={`p-2 rounded-lg my-2 w-fit max-w-xs ${
                msg.type === "user"
                  ? "bg-blue-500 text-white self-end ml-auto"
                  : "bg-gray-200 text-black self-start"
              }`}
            >
              {msg.text}
            </div>
          ))}
          {loading && <p className="text-gray-500">Processing...</p>}
        </div>

        <div className="flex items-center mt-3 gap-2">
          <input
            type="text"
            className="flex-1 p-2 border rounded focus:outline-none"
            placeholder="Type your legal question..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && sendMessage()}
          />
          <button onClick={sendMessage} className="bg-blue-500 text-white p-2 rounded">
            Send
          </button>
        </div>

        <div className="mt-3 text-center">
          <label className="cursor-pointer bg-gray-300 p-2 rounded hover:bg-gray-400">
            Upload PDF
            <input type="file" accept="application/pdf" className="hidden" onChange={handleFileUpload} />
          </label>
        </div>
      </div>
    </div>
  );
};

export default Chatbot;
