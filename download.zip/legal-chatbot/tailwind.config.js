module.exports = {
    content: [
      "./src/**/*.{html,css,js,ts,jsx,tsx}", // Adjust this to your file structure
    ],
    theme: {
      extend: {},
    },
    plugins: [],
  }
  