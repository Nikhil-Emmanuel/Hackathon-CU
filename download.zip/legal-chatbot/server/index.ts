import express, { Request, Response } from 'express';
import process from 'node:process';
import { Buffer } from 'node:buffer';
import OpenAI from 'openai';
import * as dotenv from 'dotenv'; // Import the dotenv module
import multer from 'multer';
import pdfParse from 'pdf-parse';
import path from 'path';
import { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold, Content, Part } from "@google/generative-ai";
dotenv.config();

// Initialize Gemini client
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY ?? 'AIzaSyCJnyPDd7wAHsppZKZjpx0n73CG-7JXB74');
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash-latest" });


// Initialize OpenAI client (not used but kept for reference or potential future use)
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY,
});

// Initialize Express
const app = express();

// Middleware to serve static files (HTML, CSS, JS, etc.)
app.use(express.static(path.join(__dirname, 'public')));

// Middleware to parse JSON request bodies
app.use(express.json());

// Setup multer for handling file uploads
const storage = multer.memoryStorage();
const upload = multer({ storage: storage });

// Function to extract text from PDF
const extractTextFromPDF = async (pdfBuffer: Buffer): Promise<string> => {
  try {
    const data = await pdfParse(pdfBuffer);
    return data.text.trim();
  } catch (error) {
    console.error("Error extracting text from PDF:", error);
    return '';
  }
};

// Function to process legal queries using Gemini
const getLegalAssistance = async (userInput: string): Promise<string> => {
  try {
    const chatPrompt = `Provide clear, concise legal assistance based on the following query: "${userInput}"`;
    const safetySettings = [
        {
            category: HarmCategory.HARM_CATEGORY_HARASSMENT,
            threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        },
        {
            category: HarmCategory.HARM_CATEGORY_HATE_SPEECH,
            threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
        },
    ];
    const result = await model.generateContent({
        contents: [{ role: "user", parts: [{ text: chatPrompt }]}],
        safetySettings,
        generationConfig: { maxOutputTokens: 150 },
    });

    return result.response?.text()?.trim() || "Sorry, I couldn't process your request.";
  } catch (error) {
    console.error("Error with GenAI API:", error);
    return "Sorry, something went wrong. Please try again later.";
  }
};

// Root route to prevent "Cannot GET /" error and serve index.html
app.get('/', (req: Request, res: Response) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Health check endpoint
app.get('/health', (req: Request, res: Response) => {
  res.status(200).send("Server is up and running");
});

// Endpoint to upload a PDF and process its content
app.post('/upload-pdf', upload.single('file'), async (req: Request, res: Response): Promise<void> => {
  if (!req.file) {
    res.status(400).send("No file uploaded");
    return;
  }

  try {
    // Extract text from the uploaded PDF
    const pdfText = await extractTextFromPDF(req.file.buffer);

    if (!pdfText) {
      res.status(400).send("Could not extract text from PDF");
      return;
    }

    // Process the extracted text as a legal query for OpenAI
    const legalResponse = await getLegalAssistance(pdfText);
    res.status(200).json({ response: legalResponse });
  } catch (error) {
    console.error("Error processing PDF:", error);
    res.status(500).send("Internal Server Error");
  }
});

// Endpoint to handle legal queries
app.post('/legal-query', async (req: Request, res: Response): Promise<void> => {
  const { query, userId } = req.body;

  if (!query || !userId) {
    res.status(400).send("Missing required fields: 'query' or 'userId'");
    return;
  }

  try {
    const legalResponse = await getLegalAssistance(query);
    res.status(200).json({ response: legalResponse });
  } catch (error) {
    console.error("Error processing request:", error);
    res.status(500).send("Internal Server Error");
  }
});

const port = process.env.PORT || 3000;
const host = process.env.HOST || 'localhost';

app.listen(port, () => {
  console.log(`Server is running at http://${host}:${port}`);
});
